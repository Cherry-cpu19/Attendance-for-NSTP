param(
  [Parameter(Mandatory = $true)]
  [string]$BackupPath
)

$ErrorActionPreference = 'Stop'
$resolvedBackupPath = (Resolve-Path -LiteralPath $BackupPath).Path
Add-Type -AssemblyName System.IO.Compression.FileSystem
$archive = [System.IO.Compression.ZipFile]::OpenRead($resolvedBackupPath)
$stagePath = Join-Path ([System.IO.Path]::GetTempPath()) "nstp-restore-drill-$([guid]::NewGuid().ToString('N'))"

try {
  $entries = @{}
  foreach ($entry in $archive.Entries) {
    $name = $entry.FullName
    $segments = $name.Split('/')
    if ([string]::IsNullOrWhiteSpace($name) -or $entry.Name -eq '' -or $name.Contains('\') -or $name.Contains(':') -or
        $name.StartsWith('/') -or $name -match '(^|/)\.\.?(/|$)' -or $segments -contains '') {
      throw "Unsafe archive path: $name"
    }
    if ($entries.ContainsKey($name)) {
      throw "Duplicate archive path: $name"
    }
    if ($name -ne 'backup.json' -and $name -notmatch '^(submissions|profile-pictures)/') {
      throw "Unexpected archive entry: $name"
    }
    $entries[$name] = $entry
  }

  if (-not $entries.ContainsKey('backup.json')) {
    throw 'The archive does not contain backup.json.'
  }
  $backupEntry = $entries['backup.json']
  if ($backupEntry.Length -gt 100MB) {
    throw 'backup.json is unexpectedly large.'
  }
  $reader = [System.IO.StreamReader]::new($backupEntry.Open())
  try {
    $backup = $reader.ReadToEnd() | ConvertFrom-Json
  } finally {
    $reader.Dispose()
  }
  if ($backup.format -ne 'nstp-attendance-backup' -or $backup.version -ne 1 -or $null -eq $backup.state) {
    throw 'Unsupported backup format or version.'
  }
  foreach ($collection in @('users', 'sessions', 'attendance', 'qrTokens', 'passwordResetTokens', 'sections', 'tasks', 'submissions', 'activityLogs')) {
    if ($null -eq $backup.state.$collection -or -not ($backup.state.$collection -is [System.Array])) {
      throw "Invalid or missing state collection: $collection"
    }
  }

  foreach ($submission in @($backup.state.submissions)) {
    if ([string]::IsNullOrWhiteSpace($submission.fileName) -or [System.IO.Path]::GetFileName($submission.fileName) -ne $submission.fileName) {
      throw "Invalid submission file reference: $($submission.fileName)"
    }
    if (-not $entries.ContainsKey("submissions/$($submission.fileName)")) {
      throw "Missing submission file: $($submission.fileName)"
    }
  }
  foreach ($user in @($backup.state.users)) {
    if ($user.profilePictureFile) {
      if ([System.IO.Path]::GetFileName($user.profilePictureFile) -ne $user.profilePictureFile -or
          -not $entries.ContainsKey("profile-pictures/$($user.profilePictureFile)")) {
        throw "Missing or invalid profile picture: $($user.profilePictureFile)"
      }
    }
  }

  New-Item -ItemType Directory -Path $stagePath | Out-Null
  New-Item -ItemType Directory -Path (Join-Path $stagePath 'submissions') | Out-Null
  New-Item -ItemType Directory -Path (Join-Path $stagePath 'profile-pictures') | Out-Null
  $stateJson = ConvertTo-Json -InputObject $backup.state -Depth 100
  [System.IO.File]::WriteAllText(
    (Join-Path $stagePath 'attendance.json'),
    $stateJson,
    [System.Text.UTF8Encoding]::new($false)
  )

  foreach ($name in $entries.Keys) {
    if ($name -eq 'backup.json') {
      continue
    }
    $destination = Join-Path $stagePath ($name -replace '/', [System.IO.Path]::DirectorySeparatorChar)
    $destinationDirectory = [System.IO.Path]::GetDirectoryName($destination)
    New-Item -ItemType Directory -Path $destinationDirectory -Force | Out-Null
    $inputStream = $entries[$name].Open()
    $outputStream = [System.IO.File]::Create($destination)
    try {
      $inputStream.CopyTo($outputStream)
    } finally {
      $outputStream.Dispose()
      $inputStream.Dispose()
    }
  }

  Write-Output "Backup verified and restored to staging directory: $stagePath"
  Write-Output 'This staged copy is safe for a restore drill; the live data directory was not changed.'
} finally {
  $archive.Dispose()
}
