const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const net = require('node:net');
const { spawn, execFileSync } = require('node:child_process');
const { after, test } = require('node:test');

const temp = fs.mkdtempSync(path.join(os.tmpdir(), 'nstp-app-test-'));
let appProcess;
let smtpServer;
let appOutput = '';
let smtpMessage = '';
let stagingPath = '';
let baseUrl = '';

function freePort() {
  return new Promise((resolve, reject) => {
    const server = net.createServer();
    server.once('error', reject);
    server.listen(0, '127.0.0.1', () => {
      const { port } = server.address();
      server.close(error => error ? reject(error) : resolve(port));
    });
  });
}

function makeSmtpServer() {
  return net.createServer(socket => {
    socket.write('220 localhost test SMTP\r\n');
    let buffer = '';
    let message = '';
    let inData = false;
    socket.on('data', chunk => {
      buffer += chunk.toString();
      while (buffer.includes('\r\n')) {
        const end = buffer.indexOf('\r\n');
        const line = buffer.slice(0, end);
        buffer = buffer.slice(end + 2);
        if (inData) {
          if (line === '.') {
            smtpMessage = message;
            inData = false;
            socket.write('250 queued\r\n');
          } else {
            message += `${line}\n`;
          }
        } else if (/^(EHLO|HELO)/i.test(line)) {
          socket.write('250-localhost\r\n250 SIZE 35882577\r\n');
        } else if (/^(MAIL FROM|RCPT TO)/i.test(line)) {
          socket.write('250 ok\r\n');
        } else if (/^DATA/i.test(line)) {
          inData = true;
          socket.write('354 end with dot\r\n');
        } else if (/^QUIT/i.test(line)) {
          socket.write('221 bye\r\n');
          socket.end();
        } else {
          socket.write('250 ok\r\n');
        }
      }
    });
  });
}

function makeClient() {
  return { cookie: '', csrf: '' };
}

async function request(client, endpoint, { method = 'GET', body } = {}) {
  const headers = {};
  if (client.cookie) headers.cookie = client.cookie;
  if (method !== 'GET') {
    headers['x-csrf-token'] = client.csrf;
    if (body !== undefined) headers['content-type'] = 'application/json';
  }
  const response = await fetch(`${baseUrl}${endpoint}`, {
    method,
    headers,
    body: body === undefined ? undefined : JSON.stringify(body)
  });
  const setCookie = response.headers.get('set-cookie');
  if (setCookie) client.cookie = setCookie.split(';')[0];
  const data = await response.json().catch(() => ({}));
  if (data.csrfToken) client.csrf = data.csrfToken;
  return { status: response.status, data };
}

async function prepare(client) {
  const response = await request(client, '/api/csrf');
  assert.equal(response.status, 200);
  client.csrf = response.data.token;
}

async function getCaptcha(client) {
  const response = await request(client, '/api/captcha');
  assert.equal(response.status, 200);
  return response.data.question;
}

async function login(client, role, email, password, username = '') {
  const captchaAnswer = await getCaptcha(client);
  return request(client, '/api/auth/login', {
    method: 'POST',
    body: { role, email, username, password, captchaAnswer }
  });
}

async function startApp() {
  const smtpPort = await freePort();
  const appPort = await freePort();
  smtpServer = makeSmtpServer();
  await new Promise(resolve => smtpServer.listen(smtpPort, '127.0.0.1', resolve));
  baseUrl = `http://127.0.0.1:${appPort}`;
  appProcess = spawn(process.execPath, ['server.js'], {
    cwd: path.join(__dirname, '..'),
    env: {
      ...process.env,
      NODE_ENV: 'test',
      DATA_DIR: path.join(temp, 'live-data'),
      PORT: String(appPort),
      SESSION_SECRET: 'integration-test-session-secret-0123456789',
      ADMIN_USERNAME: 'mfa-test',
      ADMIN_EMAIL: 'mfa-test@example.com',
      ADMIN_PASSWORD: 'AdminPass123!',
      ADMIN_EMAIL_MFA: 'true',
      SMTP_HOST: '127.0.0.1',
      SMTP_PORT: String(smtpPort),
      SMTP_SECURE: 'false',
      SMTP_FROM: 'NSTP Test <no-reply@test.local>',
      SMTP_USER: '',
      SMTP_PASS: ''
    },
    stdio: ['ignore', 'pipe', 'pipe']
  });
  appProcess.stdout.on('data', chunk => { appOutput += chunk.toString(); });
  appProcess.stderr.on('data', chunk => { appOutput += chunk.toString(); });

  for (let attempt = 0; attempt < 80; attempt++) {
    if (appProcess.exitCode !== null) throw new Error(`App exited early: ${appOutput}`);
    try {
      if ((await fetch(`${baseUrl}/api/csrf`)).ok) return;
    } catch {}
    await new Promise(resolve => setTimeout(resolve, 100));
  }
  throw new Error(`App did not become ready: ${appOutput}`);
}

after(async () => {
  if (appProcess && appProcess.exitCode === null) {
    appProcess.kill();
    await new Promise(resolve => appProcess.once('exit', resolve));
  }
  if (smtpServer) await new Promise(resolve => smtpServer.close(resolve));
  if (stagingPath && stagingPath.startsWith(os.tmpdir())) fs.rmSync(stagingPath, { recursive: true, force: true });
  fs.rmSync(temp, { recursive: true, force: true });
});

test('student setup, admin email MFA, attendance audit, and backup restore work end to end', async () => {
  await startApp();

  const homePage = await fetch(`${baseUrl}/`);
  assert.equal(homePage.status, 200);
  assert.match(await homePage.text(), /rel="manifest" href="\/manifest\.webmanifest"/);
  const manifestResponse = await fetch(`${baseUrl}/manifest.webmanifest`);
  assert.equal(manifestResponse.status, 200);
  const manifest = await manifestResponse.json();
  assert.equal(manifest.display, 'standalone');
  assert.deepEqual(manifest.icons.map(icon => icon.sizes), ['192x192', '512x512']);
  const workerResponse = await fetch(`${baseUrl}/service-worker.js`);
  assert.equal(workerResponse.status, 200);
  const worker = await workerResponse.text();
  assert.match(worker, /url\.pathname\.startsWith\('\/api\/'\)/);
  for (const [file, size] of [['app-192.png', 192], ['app-512.png', 512]]) {
    const iconResponse = await fetch(`${baseUrl}/icons/${file}`);
    assert.equal(iconResponse.status, 200);
    const icon = Buffer.from(await iconResponse.arrayBuffer());
    assert.deepEqual([...icon.subarray(0, 8)], [137, 80, 78, 71, 13, 10, 26, 10]);
    assert.equal(icon.readUInt32BE(16), size);
    assert.equal(icon.readUInt32BE(20), size);
  }

  const student = makeClient();
  await prepare(student);
  const registration = await request(student, '/api/auth/register', {
    method: 'POST',
    body: {
      name: 'Test Student',
      email: 'student@test.local',
      studentNumber: 'NSTP-12345',
      sectionName: 'NSTP Test Section',
      captchaAnswer: await getCaptcha(student)
    }
  });
  assert.equal(registration.status, 201, JSON.stringify(registration.data));
  assert.equal(registration.data.user.mustChangePassword, true);
  assert.equal((await request(student, '/api/sessions')).status, 403);
  const passwordSet = await request(student, '/api/student/password', {
    method: 'POST',
    body: { currentPassword: 'NSTP-12345', password: 'MyPrivatePass123!' }
  });
  assert.equal(passwordSet.status, 200, JSON.stringify(passwordSet.data));
  assert.equal(passwordSet.data.user.mustChangePassword, false);
  assert.equal((await login(student, 'student', 'student@test.local', 'NSTP-12345')).status, 401);
  assert.equal((await login(student, 'student', 'student@test.local', 'MyPrivatePass123!')).status, 200);

  const admin = makeClient();
  await prepare(admin);
  const firstFactor = await login(admin, 'admin', 'mfa-test@example.com', 'AdminPass123!', 'mfa-test');
  assert.equal(firstFactor.status, 200, JSON.stringify(firstFactor.data));
  assert.equal(firstFactor.data.requiresTwoFactor, true);
  const code = smtpMessage.match(/sign-in code is (\d{6})/i)?.[1];
  assert.ok(code, 'The SMTP test server did not receive an email code.');
  const secondFactor = await request(admin, '/api/auth/admin/verify-two-factor', {
    method: 'POST',
    body: { code }
  });
  assert.equal(secondFactor.status, 200, JSON.stringify(secondFactor.data));
  assert.equal(secondFactor.data.user.role, 'admin');

  const sections = await request(admin, '/api/sections');
  const section = sections.data.sections.find(item => item.name === 'NSTP Test Section');
  assert.ok(section);
  const now = new Date();
  const eventDate = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(now.getDate()).padStart(2, '0')}`;
  const createdSession = await request(admin, '/api/sessions', {
    method: 'POST',
    body: {
      title: 'Integration Test Session',
      eventDate,
      startTime: '09:00',
      startAt: now.toISOString(),
      location: 'Test site',
      sectionId: section.id
    }
  });
  assert.equal(createdSession.status, 201, JSON.stringify(createdSession.data));
  const qr = await request(student, '/api/student/qr', { method: 'POST', body: {} });
  assert.equal(qr.status, 200, JSON.stringify(qr.data));
  const checkIn = await request(admin, '/api/admin/attendance/scan', {
    method: 'POST',
    body: { token: qr.data.qrValue, sessionId: createdSession.data.session.id, action: 'in' }
  });
  assert.equal(checkIn.status, 200, JSON.stringify(checkIn.data));

  const localDateTime = date => `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')}T${String(date.getHours()).padStart(2, '0')}:${String(date.getMinutes()).padStart(2, '0')}`;
  const correction = {
    checkIn: localDateTime(new Date(Date.now() - 60000)),
    checkOut: localDateTime(new Date()),
    reason: 'Corrected after sign-in sheet review'
  };
  assert.equal((await request(admin, '/api/attendance/1', { method: 'PUT', body: { checkIn: correction.checkIn } })).status, 400);
  assert.equal((await request(admin, '/api/attendance/1', { method: 'PUT', body: correction })).status, 200);
  const logs = await request(admin, '/api/admin/activity-logs');
  assert.ok(logs.data.logs.some(item => item.action === 'attendance_corrected' && item.details.includes(correction.reason)));
  assert.equal((await request(admin, '/api/attendance/1', { method: 'DELETE', body: {} })).status, 400);
  assert.equal((await request(admin, '/api/attendance/1', {
    method: 'DELETE',
    body: { reason: 'Duplicate entry confirmed' }
  })).status, 200);

  const rawBackup = await fetch(`${baseUrl}/api/admin/backup.zip`, { headers: { cookie: admin.cookie } });
  assert.equal(rawBackup.status, 200);
  const backupPath = path.join(temp, 'test-backup.zip');
  fs.writeFileSync(backupPath, Buffer.from(await rawBackup.arrayBuffer()));
  const verifyOutput = execFileSync('powershell.exe', [
    '-NoProfile', '-ExecutionPolicy', 'Bypass', '-File',
    path.join(__dirname, '..', 'scripts', 'verify-backup.ps1'), '-BackupPath', backupPath
  ], { encoding: 'utf8' });
  stagingPath = verifyOutput.match(/restored to staging directory: (.+)/i)?.[1]?.trim() || '';
  assert.ok(stagingPath && fs.existsSync(path.join(stagingPath, 'attendance.json')), verifyOutput);
  const restored = JSON.parse(fs.readFileSync(path.join(stagingPath, 'attendance.json'), 'utf8'));
  assert.equal(restored.attendance.length, 0);
  assert.ok(restored.activityLogs.some(item => item.action === 'attendance_removed'));
});
