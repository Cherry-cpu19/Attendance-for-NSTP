const CACHE_NAME = 'nstp-app-shell-v1';
const APP_SHELL = [
  '/',
  '/manifest.webmanifest',
  '/styles.css',
  '/app.js',
  '/icons/app-192.png',
  '/icons/app-512.png'
];

async function cacheResponse(request, response) {
  if (!response.ok) return;
  try {
    const cache = await caches.open(CACHE_NAME);
    await cache.put(request, response.clone());
  } catch (error) {
    console.error('Could not update the offline app shell cache:', error);
  }
}

self.addEventListener('install', event => {
  event.waitUntil(Promise.all([
    caches.open(CACHE_NAME).then(cache => cache.addAll(APP_SHELL)),
    self.skipWaiting()
  ]));
});

self.addEventListener('activate', event => {
  event.waitUntil(
    caches.keys().then(keys => Promise.all(
      keys.filter(key => key.startsWith('nstp-app-shell-') && key !== CACHE_NAME)
        .map(key => caches.delete(key))
    )).then(() => self.clients.claim())
  );
});

self.addEventListener('fetch', event => {
  const request = event.request;
  const url = new URL(request.url);
  if (request.method !== 'GET' || url.origin !== self.location.origin || url.pathname.startsWith('/api/')) return;

  if (request.mode === 'navigate') {
    event.respondWith(
      fetch(request).then(async response => {
        await cacheResponse('/', response);
        return response;
      }).catch(async () => (await caches.match('/')) || Response.error())
    );
    return;
  }

  if (APP_SHELL.includes(url.pathname)) {
    event.respondWith(
      caches.match(request).then(cached => cached || fetch(request).then(async response => {
        await cacheResponse(request, response);
        return response;
      }))
    );
  }
});
