let csrf = '';
let currentUser = null;
let authMode = 'login';
let scanAction = 'in';
let qrInterval = null;
let activeSessionId = null;
let activeSessionTitle = '';
let activeQrToken = '';
let dashboardSessions = [];
let sessionQuery = '';
let studentQuery = '';
let dashboardSections = [];
let dashboardTasks = [];
let adminScanAction = 'in';
let studentQrValue = '';
let profilePreviewUrl = '';
let attendanceRefreshInterval = null;
let latestAttendanceSummary = null;
const $ = id => document.getElementById(id);
let deferredInstallPrompt = null;
const installButton = $('install-app');

window.addEventListener('beforeinstallprompt', event => {
  event.preventDefault();
  deferredInstallPrompt = event;
  installButton.classList.remove('hidden');
});

installButton.addEventListener('click', async () => {
  if (!deferredInstallPrompt) return;
  const prompt = deferredInstallPrompt;
  deferredInstallPrompt = null;
  installButton.disabled = true;
  installButton.classList.add('hidden');
  try {
    await prompt.prompt();
    await prompt.userChoice;
  } catch (error) {
    console.error('Could not show the app installation prompt:', error);
  } finally {
    installButton.disabled = false;
  }
});

window.addEventListener('appinstalled', () => {
  deferredInstallPrompt = null;
  installButton.classList.add('hidden');
});

if ('serviceWorker' in navigator) {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('/service-worker.js')
      .catch(error => console.error('Could not register the app service worker:', error));
  });
}

const escapeHtml = value => String(value ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const dateText = value => value ? new Date(`${value}T00:00:00`).toLocaleDateString(undefined,{year:'numeric',month:'short',day:'numeric'}) : '—';
const todayText = () => { const today = new Date(); return `${today.getFullYear()}-${String(today.getMonth()+1).padStart(2,'0')}-${String(today.getDate()).padStart(2,'0')}`; };
const sessionTimeText = (value,startAt) => startAt ? new Date(startAt).toLocaleTimeString(undefined,{hour:'numeric',minute:'2-digit'}) : value ? new Date(`1970-01-01T${value}:00`).toLocaleTimeString(undefined,{hour:'numeric',minute:'2-digit'}) : 'Time not set';
const timeText = value => value ? new Date(value).toLocaleString(undefined,{dateStyle:'medium',timeStyle:'short'}) : '—';
const localDateTimeValue = value => { const date=new Date(value);const pad=part=>String(part).padStart(2,'0');return `${date.getFullYear()}-${pad(date.getMonth()+1)}-${pad(date.getDate())}T${pad(date.getHours())}:${pad(date.getMinutes())}`; };
function studentSurname(name){
 const parts=String(name||'').trim().split(/\s+/).filter(Boolean);
 const suffixes=new Set(['jr','jr.','sr','sr.','ii','iii','iv','v']);
 if(parts.length>1&&suffixes.has(parts.at(-1).toLowerCase()))parts.pop();
 const particles=new Set(['de','del','dela','la','las','los','van','von','san','santa','da','dos','di']);
 let start=parts.length-1;
 while(start>0&&particles.has(parts[start-1].toLowerCase()))start--;
 return parts.slice(start).join(' ')||String(name||'Student');
}
function initials(name){
 return String(name||'Student').trim().split(/\s+/).filter(Boolean).slice(0,2).map(part=>part[0].toUpperCase()).join('');
}
function setProfilePicturePreview(source){
 const image=$('profile-picture-preview');const placeholder=$('profile-picture-placeholder');
 if(source){image.src=source;image.classList.remove('hidden');placeholder.classList.add('hidden');}
 else{image.removeAttribute('src');image.classList.add('hidden');placeholder.classList.remove('hidden');}
}
function renderProfileAvatar(){
 const avatar=$('profile-avatar');
 if(currentUser.hasProfilePicture){
  avatar.innerHTML='<img src="/api/student/profile-picture" alt="">';
 }else{
  avatar.textContent=initials(currentUser.name);
 }
}
function clearProfilePreviewUrl(){
 if(profilePreviewUrl){URL.revokeObjectURL(profilePreviewUrl);profilePreviewUrl='';}
}
function showNotice(message, success=false) { const n=$('notice'); n.textContent=message; n.classList.toggle('success',success); n.classList.remove('hidden'); window.scrollTo({top:0,behavior:'smooth'}); setTimeout(()=>n.classList.add('hidden'),5500); }
function captchaErrorMessage(error){
 if(location.hostname==='127.0.0.1'&&location.port==='5500'&&location.pathname.toLowerCase().endsWith('/public/index.html')){
  return 'Live Server only serves the page, not its API. Run node server.js in the app folder, then open http://localhost:3000.';
 }
 if(error.name==='AbortError')return 'The verification code request timed out. Check that the app server is running, then try again.';
 return error.message||'Could not load the verification code. Check that the app server is running, then try again.';
}
async function api(url, options={}) {
  const headers = {...(options.body instanceof FormData ? {} : {'Content-Type':'application/json'}),...(options.headers||{})};
  if (options.method && options.method !== 'GET') headers['X-CSRF-Token']=csrf;
  const response = await fetch(url,{credentials:'same-origin',...options,headers});
  const data = response.status===204 ? {} : await response.json().catch(()=>({error:'The server returned an invalid response.'}));
  if (!response.ok) { if(response.status===401 && !url.includes('/auth/')) renderSignedOut(); throw new Error(data.error || 'Request failed.'); }
  if(data.csrfToken) csrf=data.csrfToken;
  return data;
}
async function bootstrap() {
  try {
    csrf=(await api('/api/csrf')).token;
    await loadAuthOptions();
    const {user}=await api('/api/auth/me');
    if(user) {currentUser=user; await renderDashboard();}
    else {
      const resetToken=new URLSearchParams(location.hash.slice(1)).get('reset');
      if(resetToken){pendingResetToken=resetToken;$('reset-dialog').showModal();}
    }
  }
  catch(err) {
    if($('captcha-question').textContent==='Loading code…'){
      $('captcha-question').textContent='Code unavailable';
      $('captcha-answer').disabled=true;
      $('auth-submit').disabled=true;
      $('captcha-hint').textContent=captchaErrorMessage(err);
    }
    showNotice(captchaErrorMessage(err));
  }
}
let pendingResetToken = '';
async function loadCaptcha(){
 $('captcha-question').textContent='Loading code…';
 $('captcha-answer').value='';
 $('captcha-answer').disabled=true;
 $('auth-submit').disabled=true;
 const controller=new AbortController();
 const timeout=setTimeout(()=>controller.abort(),10000);
 try{
  const {question}=await api('/api/captcha',{signal:controller.signal});
  if(typeof question!=='string'||!/^[A-Z0-9]{6}$/.test(question))throw new Error('The server returned an invalid verification code.');
  $('captcha-question').textContent=question;
  $('captcha-answer').disabled=false;
  $('auth-submit').disabled=false;
 }catch(error){
  $('captcha-question').textContent='Code unavailable';
  const message=captchaErrorMessage(error);
  $('captcha-hint').textContent=message;
  throw new Error(message);
 }finally{
  clearTimeout(timeout);
 }
}
async function loadAuthOptions(){await loadCaptcha();}
async function renderSignedOut(){clearInterval(attendanceRefreshInterval);attendanceRefreshInterval=null;currentUser=null;if($('student-password-dialog').open)$('student-password-dialog').close();$('dashboard').classList.add('hidden');$('auth-view').classList.remove('hidden');$('identity').classList.add('hidden');$('admin-otp-form').classList.add('hidden');$('auth-form').classList.remove('hidden');$('auth-tabs').classList.remove('hidden');$('forgot-password').classList.remove('hidden');$('auth-account-hint').classList.remove('hidden');try{await loadAuthOptions();}catch(error){showNotice(error.message);}}
function renderSectionOptions(select,sections,includeAll){
 const options=includeAll?'<option value="">All sections</option>':'<option value="">Choose your ISU section</option>';
 select.innerHTML=options+sections.map(section=>`<option value="${section.id}">${escapeHtml(section.name)}</option>`).join('');
}
function updateLoginRole(){
 const admin=document.querySelector('[name="loginRole"]:checked')?.value==='admin';
 $('email-label').textContent=admin?'Admin username':'Email address';
 $('email').type=admin?'text':'email';
 $('email').autocomplete=admin?'username':'email';
 $('email').placeholder=admin?'Enter your admin username':'';
 $('password-label').textContent=admin?'Admin password':'Password';
 $('password-hint').textContent=admin?'Enter your admin password.':'Use your private password. New accounts change the temporary password after first sign-in.';
 $('password').minLength=admin?10:1;
 $('password').autocomplete='current-password';
}
function setAuthMode(mode){authMode=mode;document.querySelectorAll('[data-auth-tab]').forEach(t=>t.classList.toggle('active',t.dataset.authTab===mode));$('login-role-field').classList.toggle('hidden',mode!=='login');$('name-field').classList.toggle('hidden',mode!=='register');$('password-field').classList.toggle('hidden',mode==='register');$('name').required=mode==='register';$('student-number').required=mode==='register';$('student-section').required=mode==='register';$('password').required=mode==='login';$('auth-submit').textContent=mode==='login'?'Sign in':'Create student account';if(mode==='login')updateLoginRole();else{$('email-label').textContent='Email address';$('email').type='email';$('email').autocomplete='email';$('email').placeholder='';}}
setAuthMode(authMode);
document.querySelectorAll('[data-auth-tab]').forEach(button=>button.addEventListener('click',()=>setAuthMode(button.dataset.authTab)));
document.querySelectorAll('[name="loginRole"]').forEach(radio=>radio.addEventListener('change',updateLoginRole));
document.querySelectorAll('[data-close-dialog]').forEach(button=>button.addEventListener('click',()=>$(button.dataset.closeDialog).close()));
$('forgot-password').addEventListener('click',()=>{
 const role=document.querySelector('[name="loginRole"]:checked')?.value||'student';
 $('forgot-email').value='';
 $('forgot-title').textContent=role==='admin'?'Admin password recovery':'Student password recovery';
 $('forgot-description').textContent=role==='admin'
  ?'Enter the email address registered to the administrator account. If it matches, we’ll send a secure reset link to that email.'
  :'Enter the email address used when you registered. If it matches, we’ll send a secure password-reset link to that email.';
 $('forgot-dialog').showModal();
});
$('forgot-form').addEventListener('submit',async event=>{
  event.preventDefault();
  try {
    const role=document.querySelector('[name="loginRole"]:checked')?.value||'student';
    const {message}=await api('/api/auth/forgot-password',{method:'POST',body:JSON.stringify({email:$('forgot-email').value,role})});
    $('forgot-dialog').close();
    showNotice(message,true);
  } catch(error) { showNotice(error.message); }
});
$('reset-form').addEventListener('submit',async event=>{
  event.preventDefault();
  const password=$('reset-password').value;
  if(password!==$('reset-password-confirm').value){showNotice('The passwords do not match.');return;}
  try {
    await api('/api/auth/reset-password',{method:'POST',body:JSON.stringify({token:pendingResetToken,password})});
    pendingResetToken='';
    history.replaceState(null,'',`${location.pathname}${location.search}`);
    $('reset-form').reset();
    $('reset-dialog').close();
    $('email').focus();
    showNotice('Your password has been reset. Sign in with your new password.',true);
  } catch(error) { showNotice(error.message); }
});
$('edit-profile').addEventListener('click',()=>{
 $('profile-name').value=currentUser.name;
 $('profile-email').value=currentUser.email;
 $('profile-picture').value='';
 clearProfilePreviewUrl();
 setProfilePicturePreview(currentUser.hasProfilePicture?`/api/student/profile-picture?v=${Date.now()}`:'');
 $('profile-dialog').showModal();
});
$('profile-picture').addEventListener('change',event=>{
 const file=event.currentTarget.files[0];
 if(!file){clearProfilePreviewUrl();setProfilePicturePreview(currentUser.hasProfilePicture?`/api/student/profile-picture?v=${Date.now()}`:'');return;}
 if(!['image/jpeg','image/png','image/webp'].includes(file.type)){
  event.currentTarget.value='';
  showNotice('Choose a JPG, PNG, or WebP image.');
  return;
 }
 if(file.size>5*1024*1024){
  event.currentTarget.value='';
  showNotice('Profile pictures must be 5 MB or smaller.');
  return;
 }
 clearProfilePreviewUrl();
 profilePreviewUrl=URL.createObjectURL(file);
 setProfilePicturePreview(profilePreviewUrl);
});
$('profile-form').addEventListener('submit',async event=>{
 event.preventDefault();
 try{
  const body=new FormData(event.currentTarget);
  const {user}=await api('/api/student/profile',{method:'PUT',body});
  currentUser=user;
  $('profile-form').reset();
  clearProfilePreviewUrl();
  $('profile-dialog').close();
  await renderDashboard();
  showNotice('Your profile has been updated.',true);
 }catch(error){showNotice(error.message);}
});
$('refresh-captcha').addEventListener('click',async()=>{try{await loadCaptcha();}catch(e){showNotice(e.message);}});
$('auth-form').addEventListener('submit',async event=>{
 event.preventDefault();
 const authForm=event.currentTarget;
 const form=new FormData(authForm);
 const payload={email:form.get('email'),password:form.get('password'),captchaAnswer:form.get('captchaAnswer')};
 if(authMode==='register'){
  payload.name=form.get('name');payload.studentNumber=form.get('studentNumber');payload.sectionName=form.get('sectionName');
 }else{
  payload.role=form.get('loginRole');
  if(payload.role==='admin')payload.username=form.get('email');
 }
 try{
  const result=await api(`/api/auth/${authMode}`,{method:'POST',body:JSON.stringify(payload)});
  authForm.reset();
  if(result.requiresTwoFactor){
   authForm.classList.add('hidden');
   $('auth-tabs').classList.add('hidden');
   $('forgot-password').classList.add('hidden');
   $('auth-account-hint').classList.add('hidden');
   $('admin-otp-form').classList.remove('hidden');
   $('admin-otp-code').focus();
   showNotice('A sign-in code was sent to the administrator email address.',true);
   return;
  }
  currentUser=result.user;
  await renderDashboard();
  showNotice(authMode==='register'?'Your account is ready. Choose a private password to continue.':'Welcome back.',true);
 }catch(error){
  try{await loadCaptcha();}catch(refreshError){showNotice(`${error.message} ${refreshError.message}`);return;}
  showNotice(error.message);
 }
});
$('admin-otp-form').addEventListener('submit',async event=>{
 event.preventDefault();
 try{
  const {user}=await api('/api/auth/admin/verify-two-factor',{method:'POST',body:JSON.stringify({code:$('admin-otp-code').value})});
  currentUser=user;
  $('admin-otp-form').reset();
  await renderDashboard();
  showNotice('Welcome back.',true);
 }catch(error){showNotice(error.message);}
});
$('admin-otp-back').addEventListener('click',async()=>{
 $('admin-otp-form').classList.add('hidden');
 $('auth-form').classList.remove('hidden');
 $('auth-tabs').classList.remove('hidden');
 $('forgot-password').classList.remove('hidden');
 $('auth-account-hint').classList.remove('hidden');
 $('admin-otp-form').reset();
 try{await loadCaptcha();}catch(error){showNotice(error.message);}
});
$('student-password-form').addEventListener('submit',async event=>{
 event.preventDefault();
 const password=$('student-new-password').value;
 if(password!==$('student-new-password-confirm').value){showNotice('The passwords do not match.');return;}
 try{
  const {user}=await api('/api/student/password',{method:'POST',body:JSON.stringify({
   currentPassword:$('student-current-password').value,
   password
  })});
  currentUser=user;
  $('student-password-form').reset();
  $('student-password-dialog').close();
  await renderDashboard();
  showNotice('Your private password is set.',true);
 }catch(error){showNotice(error.message);}
});
$('student-password-logout').addEventListener('click',()=>$('logout').click());
$('student-password-dialog').addEventListener('cancel',event=>event.preventDefault());
$('admin-create-form').addEventListener('submit',async event=>{
 event.preventDefault();
 const form=event.currentTarget;
 const values=new FormData(form);
 try{
  await api('/api/admin/admins',{method:'POST',body:JSON.stringify({
   username:values.get('username'),
   email:values.get('email'),
   password:values.get('password')
  })});
  form.reset();
  showNotice('Admin account created. They can now sign in with their own username and password.',true);
 }catch(error){showNotice(error.message);}
});
$('logout').addEventListener('click',async()=>{try{await stopCamera();await stopAdminCamera();await api('/api/auth/logout',{method:'POST',body:'{}'});await renderSignedOut();}catch(e){showNotice(e.message);}});
async function renderDashboard(){
 $('auth-view').classList.add('hidden');$('dashboard').classList.remove('hidden');$('identity').textContent=`${currentUser.name} · ${currentUser.role}`;$('identity').classList.remove('hidden');
 if(currentUser.mustChangePassword){
  if(!$('student-password-dialog').open)$('student-password-dialog').showModal();
  return;
 }
 if($('student-password-dialog').open)$('student-password-dialog').close();
 const admin=currentUser.role==='admin';$('greeting').textContent=admin?`Hello, ${currentUser.name.split(/\s+/)[0]}!`:`Hello, ${studentSurname(currentUser.name)}!`;$('edit-profile').classList.toggle('hidden',admin);$('profile-avatar').classList.toggle('hidden',admin);if(!admin)renderProfileAvatar();$('admin-panel').classList.toggle('hidden',!admin);$('student-panel').classList.toggle('hidden',admin);$('dashboard-subtitle').textContent=admin?'Manage sessions, generate QR codes, and review records.':'Your sessions and attendance records are all in one place.';
 clearInterval(attendanceRefreshInterval);
 const [{sessions},{sections},{tasks}]=await Promise.all([api('/api/sessions'),api('/api/sections'),api('/api/tasks')]);
 dashboardSessions=sessions;dashboardSections=sections;dashboardTasks=tasks;
 if(admin){
   const [attendanceSummary, activityLogs]=await Promise.all([
    api('/api/admin/attendance/summary'),
    api('/api/admin/activity-logs')
   ]);
   renderAdminAttendanceDashboard(attendanceSummary,sections);
   renderAdminNotifications(activityLogs.logs || []);
   renderAdminMonthlyOverview(sessions);
   attendanceRefreshInterval=setInterval(async()=>{
    if(currentUser?.role!=='admin')return;
    try{
      const [summary, logs] = await Promise.all([
        api('/api/admin/attendance/summary'),
        api('/api/admin/activity-logs')
      ]);
      renderAdminAttendanceDashboard(summary,dashboardSections);
      renderAdminNotifications(logs.logs || []);
    }
    catch(error){showNotice(error.message);}
   },60000);
   renderAdminSessions(sessions);renderAdminSections(sections);renderUnassignedStudents(sections);renderAdminScanSessions(sessions);renderAdminTasks(tasks);
   renderSectionOptions($('session-section'),sections,true);renderSectionOptions($('task-section'),sections,true);
 }else{
   renderStudentOverview(sessions);renderStudentNotifications(sessions,tasks);renderStudentSummary(sessions);renderStudentSessions(sessions);renderStudentTasks(tasks);
   $('dashboard-subtitle').textContent=`Your ${currentUser.section||'unassigned'} section, sessions, and tasks are all in one place.`;
 } }
function renderAdminNotifications(logs=[]){
 const root=$('admin-activity-logs');
 if(!logs.length){
   root.innerHTML='<div class="empty-state">No recent activity to show yet.</div>';
   return;
 }
 root.innerHTML=`<div class="table-wrap"><table><thead><tr><th>Time</th><th>Action</th><th>Actor</th></tr></thead><tbody>${logs.map(log=>`<tr><td>${timeText(log.createdAt)}</td><td>${escapeHtml(log.action.replace(/_/g,' '))}</td><td>${escapeHtml(log.actorLabel || 'System')}</td></tr>`).join('')}</tbody></table></div>`;
}
function renderAdminMonthlyOverview(sessions=[]){
 const root=$('admin-monthly-overview');
 const monthlyMap=new Map();
 for (const session of sessions) {
   if (!session.event_date) continue;
   const date=new Date(`${session.event_date}T00:00:00`);
   const monthKey=`${date.getFullYear()}-${String(date.getMonth()+1).padStart(2,'0')}`;
   const bucket=monthlyMap.get(monthKey) || {monthKey, totalSessions:0, present:0, eligible:0};
   bucket.totalSessions += 1;
   bucket.present += Number(session.present || 0);
   bucket.eligible += Number(session.eligible || 0);
   monthlyMap.set(monthKey,bucket);
 }
 const items=[...monthlyMap.values()].sort((a,b)=>a.monthKey.localeCompare(b.monthKey)).slice(-4);
 if (!items.length) {
   root.innerHTML='<div class="empty-state">Monthly attendance summaries will appear once sessions are recorded.</div>';
   return;
 }
 root.innerHTML=`<div class="monthly-overview-grid">${items.map(item=>{
   const rate=item.eligible ? Math.round((item.present / item.eligible) * 100) : 0;
   const label=new Date(`${item.monthKey}-01T00:00:00`).toLocaleDateString(undefined,{month:'short',year:'numeric'});
   return `<div class="monthly-overview-item"><div class="monthly-overview-header"><strong>${escapeHtml(label)}</strong><span>${rate}%</span></div><div class="monthly-overview-bar"><span style="width:${Math.min(rate,100)}%"></span></div><small>${item.present} present across ${item.totalSessions} session${item.totalSessions===1?'':'s'}</small></div>`;
 }).join('')}</div>`;
}
function renderWeeklyAttendanceWarnings(data,sections){
 const sectionFilter=$('weekly-attendance-section');
 const selectedSection=sectionFilter.value;
 sectionFilter.innerHTML='<option value="">All sections</option>'+sections.map(section=>`<option value="${section.id}">${escapeHtml(section.name)}</option>`).join('');
 if(sections.some(section=>String(section.id)===selectedSection))sectionFilter.value=selectedSection;
 const sectionId=sectionFilter.value;
 const trackedStudents=data.students.filter(student=>student.weekEligible>0&&(!sectionId||String(student.sectionId)===sectionId));
 const warnings=trackedStudents.filter(student=>student.weekLowAttendance).sort((a,b)=>a.weekAttendanceRate-b.weekAttendanceRate||a.name.localeCompare(b.name,undefined,{sensitivity:'base'}));
 $('weekly-attendance-period').textContent=`${dateText(data.weekStartDate)} through ${dateText(data.today.date)} · Below 75% attendance`;
 $('weekly-attendance-alerts').innerHTML=warnings.length?`<div class="table-wrap"><table><thead><tr><th>Student</th><th>Section</th><th>Attended</th><th>Eligible</th><th>Attendance rate</th></tr></thead><tbody>${warnings.map(student=>`<tr><td>${escapeHtml(student.name)}</td><td>${escapeHtml(student.section)}</td><td>${student.weekAttended}</td><td>${student.weekEligible}</td><td><span class="pill inactive">${student.weekAttendanceRate}%</span></td></tr>`).join('')}</tbody></table></div>`:trackedStudents.length?'<div class="empty-state">No students in this section are below 75% for the last seven days.</div>':'<div class="empty-state">No completed eligible sessions for this section in the last seven days.</div>';
}
function renderAdminAttendanceDashboard(data,sections){
 latestAttendanceSummary=data;
 const {summary,students,sessions,today}=data;
 $('admin-attendance-metrics').innerHTML=[
  {label:'Total students',value:summary.totalStudents},
  {label:'Present today',value:today.present},
  {label:'Late today',value:today.late},
  {label:'Absent today',value:today.absent},
  {label:'Attendance percentage today',value:today.attendanceRate===null?'—':`${today.attendanceRate}%`},
  {label:'Completed sessions',value:summary.conductedSessions},
  {label:'Overall attendance',value:summary.averageRate===null?'—':`${summary.averageRate}%`},
  {label:'Students below 75%',value:summary.lowAttendanceCount},
  {label:'Students tracked',value:students.filter(student=>student.eligible>0).length}
 ].map(item=>`<div class="summary-card"><span class="summary-label">${item.label}</span><strong>${item.value}</strong></div>`).join('');
 const dailyTotal=today.eligibleStudents;
 const percentage=value=>dailyTotal?value/dailyTotal*100:0;
 $('today-attendance-pie').innerHTML=dailyTotal?`<div class="daily-chart-layout"><div class="attendance-pie" role="img" aria-label="Today: ${today.present} present, ${today.late} late, ${today.absent} absent out of ${dailyTotal} scheduled students" style="--present:${percentage(today.present)}%;--late:${percentage(today.late)}%;--absent:${percentage(today.absent)}%"><span>${today.attendanceRate}%</span></div><div class="chart-legend"><div><i class="legend-present"></i>Present <strong>${today.present}</strong></div><div><i class="legend-late"></i>Late <strong>${today.late}</strong></div><div><i class="legend-absent"></i>Absent <strong>${today.absent}</strong></div></div></div>`:'<div class="empty-state">No sessions have started today yet.</div>';
 $('today-attendance-bars').innerHTML=today.sessions.length?`<div class="attendance-bars">${today.sessions.map(session=>{
  const total=session.eligible||0;
  const width=count=>total?count/total*100:0;
  return `<div class="attendance-bar-row"><div class="attendance-bar-heading"><strong>${escapeHtml(session.title)}</strong><span>${session.startTime?sessionTimeText(session.startTime,session.startAt)+' · ':''}${escapeHtml(session.section)}</span><b>${session.attendanceRate===null?'—':`${session.attendanceRate}%`}</b></div><div class="attendance-bar-track" role="img" aria-label="${escapeHtml(session.title)}: ${session.present} present, ${session.late} late, ${session.absent} absent"><span class="bar-present" style="width:${width(session.present)}%"></span><span class="bar-late" style="width:${width(session.late)}%"></span><span class="bar-absent" style="width:${width(session.absent)}%"></span></div></div>`;
 }).join('')}<div class="chart-legend chart-legend-inline"><div><i class="legend-present"></i>Present</div><div><i class="legend-late"></i>Late</div><div><i class="legend-absent"></i>Absent</div></div></div>`:'<div class="empty-state">No sessions have started today yet.</div>';
 const reportSection=$('attendance-report-section');
 const selectedSection=reportSection.value;
 reportSection.innerHTML='<option value="">All sections</option>'+sections.map(section=>`<option value="${section.id}">${escapeHtml(section.name)}</option>`).join('');
 if(sections.some(section=>String(section.id)===selectedSection))reportSection.value=selectedSection;
 const sessionRoot=$('admin-session-report');
 sessionRoot.innerHTML=sessions.length?`<div class="table-wrap"><table><thead><tr><th>Session</th><th>Date</th><th>Section</th><th>Present</th><th>Eligible</th><th>Attendance rate</th></tr></thead><tbody>${sessions.map(session=>`<tr><td>${escapeHtml(session.title)}</td><td>${dateText(session.eventDate)}</td><td>${escapeHtml(session.section)}</td><td>${session.present}</td><td>${session.eligible}</td><td>${session.attendanceRate===null?'—':`${session.attendanceRate}%`}</td></tr>`).join('')}</tbody></table></div>`:'<div class="empty-state">Completed session reports will appear here automatically.</div>';
 const lowAttendance=students.filter(student=>student.lowAttendance).sort((a,b)=>a.attendanceRate-b.attendanceRate||a.name.localeCompare(b.name,undefined,{sensitivity:'base'}));
 $('low-attendance-alerts').innerHTML=lowAttendance.length?`<div class="table-wrap"><table><thead><tr><th>Student</th><th>Section</th><th>Attended</th><th>Eligible</th><th>Attendance rate</th></tr></thead><tbody>${lowAttendance.map(student=>`<tr><td>${escapeHtml(student.name)}</td><td>${escapeHtml(student.section)}</td><td>${student.attended}</td><td>${student.eligible}</td><td><span class="pill inactive">${student.attendanceRate}%</span></td></tr>`).join('')}</tbody></table></div>`:'<div class="empty-state">No students are currently below the 75% attendance threshold.</div>';
 const topStudents = students.filter(student => student.eligible > 0 && student.attendanceRate !== null).sort((a, b) => (b.attendanceRate ?? 0) - (a.attendanceRate ?? 0) || a.name.localeCompare(b.name, undefined, { sensitivity: 'base' })).slice(0, 5);
 $('top-attendance-students').innerHTML = topStudents.length ? `<div class="rank-list">${topStudents.map((student, index) => `
    <div class="rank-row">
      <span class="rank-badge">#${index + 1}</span>
      <div class="rank-meta">
        <strong>${escapeHtml(student.name)}</strong>
        <small>${escapeHtml(student.section)}</small>
      </div>
      <span class="rank-score">${student.attendanceRate}%</span>
    </div>
  `).join('')}</div>` : '<div class="empty-state">No attendance records are available yet.</div>';
 const sectionPerformance = sections.map(section => {
   const sectionStudents = students.filter(student => student.section === section.name);
   const eligible = sectionStudents.filter(student => student.eligible > 0);
   const averageRate = eligible.length ? Math.round(eligible.reduce((sum, student) => sum + (student.attendanceRate ?? 0), 0) / eligible.length) : 0;
   const meetingTarget = eligible.filter(student => (student.attendanceRate ?? 0) >= 75).length;
   return {
     name: section.name,
     studentCount: eligible.length,
     averageRate,
     meetingTarget,
     riskCount: eligible.filter(student => (student.attendanceRate ?? 0) < 75).length
   };
 }).filter(section => section.studentCount > 0).sort((a,b)=>b.averageRate-a.averageRate||a.name.localeCompare(b.name,undefined,{sensitivity:'base'}));
 $('section-performance-panel').innerHTML = sectionPerformance.length ? `
    <div class="section-performance-list">
      ${sectionPerformance.map(section => `
        <div class="section-performance-item">
          <div class="section-performance-top">
            <strong>${escapeHtml(section.name)}</strong>
            <span>${section.averageRate}%</span>
          </div>
          <div class="section-performance-bar"><span style="width:${Math.min(section.averageRate,100)}%"></span></div>
          <div class="section-performance-meta">
            <small>${section.meetingTarget} meeting target</small>
            <small>${section.riskCount} at risk</small>
            <small>${section.studentCount} tracked</small>
          </div>
        </div>
      `).join('')}
    </div>
  ` : '<div class="empty-state">No section data is available yet.</div>';
 const weeklyTrend = [...sessions].sort((a,b)=>a.eventDate.localeCompare(b.eventDate)).slice(-4);
 $('admin-weekly-trend').innerHTML = weeklyTrend.length ? `
    <div class="weekly-trend-list">
      ${weeklyTrend.map(session => `
        <div class="weekly-trend-item">
          <div class="weekly-trend-header">
            <strong>${escapeHtml(session.title)}</strong>
            <span>${session.attendanceRate===null?'—':`${session.attendanceRate}%`}</span>
          </div>
          <div class="weekly-trend-bar"><span style="width:${session.attendanceRate===null?0:Math.min(session.attendanceRate,100)}%"></span></div>
          <small>${dateText(session.eventDate)} · ${session.present}/${session.eligible} present</small>
        </div>
      `).join('')}
    </div>
  ` : '<div class="empty-state">No recent sessions are available for trend tracking.</div>';
 renderWeeklyAttendanceWarnings(data,sections);
}
$('weekly-attendance-section').addEventListener('change',()=>{
 if(latestAttendanceSummary)renderWeeklyAttendanceWarnings(latestAttendanceSummary,dashboardSections);
});
$('print-attendance-report').addEventListener('click',()=>{
 if(!latestAttendanceSummary){showNotice('Attendance summary is not ready yet.');return;}
 const sectionId=Number($('attendance-report-section').value)||null;
 const sectionName=sectionId?$('attendance-report-section').selectedOptions[0]?.textContent:'All sections';
 const students=latestAttendanceSummary.students.filter(student=>!sectionId||Number(student.sectionId)===sectionId);
 const attended=students.reduce((total,student)=>total+student.attended,0);
 const eligible=students.reduce((total,student)=>total+student.eligible,0);
 const lowAttendance=students.filter(student=>student.lowAttendance).length;
 $('attendance-print-report').innerHTML=`
   <header class="print-report-heading">
     <span>NSTP ATTENDANCE MONITORING SYSTEM</span>
     <h1>Attendance Summary</h1>
     <p>${escapeHtml(sectionName)} · Generated ${escapeHtml(new Date().toLocaleString())}</p>
   </header>
   <div class="print-report-metrics">
     <div><span>Students included</span><strong>${students.length}</strong></div>
     <div><span>Overall attendance</span><strong>${eligible?Math.round(attended/eligible*100)+'%':'—'}</strong></div>
     <div><span>Below 75%</span><strong>${lowAttendance}</strong></div>
   </div>
   <table class="print-report-table">
     <thead><tr><th>Student</th><th>Section</th><th>Attended</th><th>Eligible</th><th>Absences</th><th>Attendance rate</th></tr></thead>
     <tbody>${students.map(student=>`<tr><td>${escapeHtml(student.name)}</td><td>${escapeHtml(student.section)}</td><td>${student.attended}</td><td>${student.eligible}</td><td>${student.absent}</td><td>${student.attendanceRate===null?'—':`${student.attendanceRate}%`}</td></tr>`).join('')}</tbody>
   </table>`;
 window.print();
});
$('download-attendance-report').addEventListener('click',async()=>{
 const sectionId=$('attendance-report-section').value;
 const query=sectionId?`?sectionId=${encodeURIComponent(sectionId)}`:'';
 try{
  const response=await fetch(`/api/admin/attendance/report.csv${query}`,{credentials:'same-origin'});
  if(!response.ok){
   const data=await response.json().catch(()=>({}));
   throw new Error(data.error||'Could not download the attendance report.');
  }
  const file=URL.createObjectURL(await response.blob());
  const link=document.createElement('a');
  link.href=file;
  link.download=`nstp-attendance-${sectionId||'all-sections'}.csv`;
  document.body.append(link);
  link.click();
  link.remove();
  setTimeout(()=>URL.revokeObjectURL(file),1000);
 }catch(error){showNotice(error.message);}
});
function filterSessions(sessions, query){ const text = String(query || '').trim().toLowerCase(); if (!text) return sessions; return sessions.filter(session => [session.title, session.location, session.event_date].some(value => String(value || '').toLowerCase().includes(text))); }
function renderAdminSessions(sessions){const root=$('sessions-grid');const filtered = filterSessions(sessions, sessionQuery);if(!filtered.length){root.innerHTML='<div class="empty-state">No sessions match your search.</div>';return;}root.innerHTML=filtered.map(s=>`<article class="session-card"><div class="card-top"><span class="pill ${s.active?'':'inactive'}">${s.active?'ACTIVE':'INACTIVE'}</span><span class="muted small">${s.attendees} attendee${s.attendees===1?'':'s'}</span></div><h3>${escapeHtml(s.title)}</h3><div class="card-meta">${dateText(s.event_date)} · ${sessionTimeText(s.start_time,s.start_at)}<br>${escapeHtml(s.location||'Location not set')}<br>${escapeHtml(s.sectionName)}</div><div class="card-actions"><button class="button primary" data-qr="${s.id}" ${s.active?'':'disabled'}>Show QR</button><button class="button light" data-records="${s.id}" data-title="${escapeHtml(s.title)}">Roster & absences</button><button class="button light" data-edit="${s.id}">Edit</button><button class="button light" data-delete="${s.id}">Delete</button></div></article>`).join('');root.querySelectorAll('[data-qr]').forEach(b=>b.onclick=()=>generateQr(Number(b.dataset.qr)));root.querySelectorAll('[data-records]').forEach(b=>b.onclick=()=>showRecords(Number(b.dataset.records),b.dataset.title));root.querySelectorAll('[data-edit]').forEach(b=>b.onclick=()=>editSession(Number(b.dataset.edit),sessions));root.querySelectorAll('[data-delete]').forEach(b=>b.onclick=()=>deleteSession(Number(b.dataset.delete)));}
function renderAdminSections(sections){
 const root=$('sections-grid');
 if(!sections.length){root.innerHTML='<div class="empty-state">Create a section before students register.</div>';return;}
 root.innerHTML=[...sections].sort((a,b)=>a.name.localeCompare(b.name,undefined,{sensitivity:'base'})).map(section=>`<details class="section-folder" data-section-folder="${section.id}"><summary><span class="section-folder-name">${escapeHtml(section.name)}</span><span class="pill">${section.student_count} STUDENTS</span></summary><div class="section-folder-content"><div class="section-folder-actions"><span class="muted small">Students in this section, sorted A–Z</span><button class="table-action" data-delete-section="${section.id}">Delete section</button></div><div data-folder-roster="${section.id}"><div class="empty-state">Open this section to load its student list.</div></div></div></details>`).join('');
 root.querySelectorAll('[data-section-folder]').forEach(folder=>folder.addEventListener('toggle',async()=>{
  if(!folder.open)return;
  const roster=folder.querySelector('[data-folder-roster]');
  if(roster.dataset.loaded)return;
  roster.innerHTML='<div class="empty-state">Loading students…</div>';
  try{
   const {students}=await api(`/api/sections/${folder.dataset.sectionFolder}/students`);
   const ordered=[...students].sort((a,b)=>a.name.localeCompare(b.name,undefined,{sensitivity:'base'}));
   roster.innerHTML=ordered.length?`<div class="table-wrap"><table><thead><tr><th>#</th><th>Student name</th><th>Email</th></tr></thead><tbody>${ordered.map((student,index)=>`<tr><td>${index+1}</td><td>${escapeHtml(student.name)}</td><td>${escapeHtml(student.email)}</td></tr>`).join('')}</tbody></table></div>`:'<div class="empty-state">No students have selected this section yet.</div>';
   roster.dataset.loaded='true';
  }catch(error){roster.innerHTML=`<div class="empty-state">${escapeHtml(error.message)}</div>`;showNotice(error.message);}
 }));
 root.querySelectorAll('[data-delete-section]').forEach(button=>button.onclick=()=>deleteSection(Number(button.dataset.deleteSection)));
}
function renderAdminScanSessions(sessions){
 const active=sessions.filter(session=>session.active);
 $('admin-scan-session').innerHTML=active.length?active.map(session=>`<option value="${session.id}">${escapeHtml(session.title)} · ${escapeHtml(session.sectionName)}</option>`).join(''):'<option value="">No active sessions</option>';
 $('admin-start-scan').disabled=!active.length;
 $('admin-submit-token').disabled=!active.length;
}
async function renderUnassignedStudents(sections){
 const panel=$('unassigned-panel');const root=$('unassigned-table');
 try{
  const {students}=await api('/api/admin/students/unassigned');
  panel.classList.toggle('hidden',students.length===0);
  if(!students.length)return;
  const sectionOptions=sections.map(section=>`<option value="${section.id}">${escapeHtml(section.name)}</option>`).join('');
  root.innerHTML=`<div class="table-wrap"><table><thead><tr><th>Student</th><th>Email</th><th>Assign section</th></tr></thead><tbody>${students.map(student=>`<tr><td>${escapeHtml(student.name)}</td><td>${escapeHtml(student.email)}</td><td><div class="assignment-row"><select aria-label="Section for ${escapeHtml(student.name)}">${sectionOptions}</select><button class="button light" data-assign-student="${student.id}">Assign</button></div></td></tr>`).join('')}</tbody></table></div>`;
  root.querySelectorAll('[data-assign-student]').forEach(button=>button.onclick=async()=>{
   const sectionId=button.parentElement.querySelector('select').value;
   try{await api(`/api/admin/students/${button.dataset.assignStudent}/section`,{method:'PUT',body:JSON.stringify({sectionId})});await renderDashboard();showNotice('Student assigned to section.',true);}catch(error){showNotice(error.message);}
  });
 }catch(error){showNotice(error.message);}
}
async function deleteSection(id){
 if(!confirm('Delete this section? Sections assigned to students, tasks, or sessions cannot be deleted.'))return;
 try{await api(`/api/sections/${id}`,{method:'DELETE'});await renderDashboard();showNotice('Section deleted.',true);}catch(error){showNotice(error.message);}
}
function renderAdminTasks(tasks){
 const root=$('admin-tasks');
 if(!tasks.length){root.innerHTML='<div class="empty-state">No tasks have been created yet.</div>';return;}
 root.innerHTML=tasks.map(task=>`<article class="session-card"><div class="card-top"><span class="pill">${task.submissionCount} SUBMITTED</span><span class="muted small">${escapeHtml(task.sectionName)}</span></div><h3>${escapeHtml(task.title)}</h3><div class="card-meta">Due ${timeText(task.dueAt)}<br>${escapeHtml(task.description||'No extra instructions')}</div><div class="card-actions"><button class="button light" data-task-submissions="${task.id}" data-title="${escapeHtml(task.title)}">View submissions</button></div></article>`).join('');
 root.querySelectorAll('[data-task-submissions]').forEach(button=>button.onclick=()=>showTaskSubmissions(Number(button.dataset.taskSubmissions),button.dataset.title));
}
function renderStudentTasks(tasks){
 const root=$('student-tasks');
 if(!tasks.length){root.innerHTML='<div class="empty-state">There are no tasks assigned to your section yet.</div>';return;}
 root.innerHTML=tasks.map(task=>{
  const submitted=task.submission;
  const late=Date.now()>new Date(task.dueAt).getTime();
  return `<article class="session-card"><div class="card-top"><span class="pill ${submitted?'':'inactive'}">${submitted?'SUBMITTED':late?'PAST DUE':'NOT SUBMITTED'}</span><span class="muted small">${escapeHtml(task.sectionName)}</span></div><h3>${escapeHtml(task.title)}</h3><div class="card-meta">Due ${timeText(task.dueAt)}<br>${escapeHtml(task.description||'No extra instructions')}</div>${submitted?`<p class="muted small">Latest file: <a href="/api/submissions/${submitted.id}/file">${escapeHtml(submitted.originalName)}</a><br>Submitted ${timeText(submitted.submittedAt)}</p>`:''}<form class="task-upload-form" data-task-upload="${task.id}"><label class="manual-label" for="task-file-${task.id}">${submitted?'Replace PDF':'Upload PDF'} · max 10 MB</label><input id="task-file-${task.id}" name="file" type="file" accept=".pdf,application/pdf" required><button class="button primary" type="submit">${submitted?'Replace submission':'Submit task'}</button></form></article>`;
 }).join('');
 root.querySelectorAll('[data-task-upload]').forEach(form=>form.addEventListener('submit',async event=>{
  event.preventDefault();
  const file=form.querySelector('input[type=file]').files[0];
  if(!file)return;
  const body=new FormData();body.append('file',file);
  try{await api(`/api/tasks/${form.dataset.taskUpload}/submissions`,{method:'POST',body});await renderDashboard();showNotice('PDF submitted successfully.',true);}catch(error){showNotice(error.message);}
 }));
}
async function showTaskSubmissions(id,title){
 $('task-submissions-title').textContent=`${title} · submissions`;$('task-submissions-panel').classList.remove('hidden');$('task-submissions-table').innerHTML='Loading…';
 try{
  const {submissions}=await api(`/api/tasks/${id}/submissions`);
  $('task-submissions-table').innerHTML=submissions.length?`<div class="table-wrap"><table><thead><tr><th>Student</th><th>Email</th><th>File</th><th>Submitted</th></tr></thead><tbody>${submissions.map(submission=>`<tr><td>${escapeHtml(submission.studentName)}</td><td>${escapeHtml(submission.studentEmail)}</td><td><a href="/api/submissions/${submission.id}/file">${escapeHtml(submission.originalName)}</a></td><td>${timeText(submission.submittedAt)}</td></tr>`).join('')}</tbody></table></div>`:'<div class="empty-state">No students have submitted this task yet.</div>';
 }catch(error){showNotice(error.message);}
}
async function showStudentQr(){
 try{const {image,qrValue,expiresAt}=await api('/api/student/qr',{method:'POST',body:'{}'});studentQrValue=qrValue;$('student-qr-image').src=image;$('student-qr-dialog').showModal();startStudentQrCountdown(expiresAt);}
 catch(error){showNotice(error.message);}
}
let studentQrTimer=null;
function startStudentQrCountdown(expiresAt){
 clearInterval(studentQrTimer);
 const tick=()=>{const left=Math.max(0,expiresAt-Date.now());$('student-qr-timer').textContent=left?`Expires in ${Math.floor(left/60000)}:${String(Math.floor(left%60000/1000)).padStart(2,'0')}`:'QR expired — generate a new one';};
 tick();studentQrTimer=setInterval(tick,1000);
}
function renderStudentOverview(sessions){
 const today=todayText();
 const past=sessions.filter(s=>s.event_date<=today);
 const attended=past.filter(s=>s.attendance_id).length;
 const rate=past.length?Math.round(attended/past.length*100):null;
 const missed=past.filter(s=>!s.attendance_id).sort((a,b)=>b.event_date.localeCompare(a.event_date));
 const upcoming=sessions.filter(s=>s.active&&s.event_date>=today).sort((a,b)=>a.event_date.localeCompare(b.event_date));
 $('student-overview-date').textContent=new Date().toLocaleDateString(undefined,{weekday:'long',year:'numeric',month:'long',day:'numeric'});
 $('attendance-progress-label').textContent=rate===null?'No past sessions yet':`${rate}%`;
 const progress=$('attendance-progress');
 progress.style.width=`${rate||0}%`;
 progress.parentElement.setAttribute('aria-valuenow',String(rate||0));
 const sessionsNeeded=rate!==null&&rate<75?Math.max(0,3*past.length-4*attended):0;
 const attendanceGuidance=$('student-attendance-guidance');
 const guidance=rate===null
   ?'Your attendance progress will appear after your first session is completed.'
   :rate<75
     ?`Attend the next ${sessionsNeeded} eligible session${sessionsNeeded===1?'':'s'} to reach at least 75%. ${upcoming.length} upcoming session${upcoming.length===1?' is':'s are'} currently scheduled.`
     :'You are at or above the 75% attendance target. Keep attending to maintain your progress.';
 attendanceGuidance.innerHTML=`
   <div class="attendance-guidance-status">
     <span class="eyebrow">YOUR ATTENDANCE TARGET</span>
     <div class="attendance-guidance-rate"><strong>${rate===null?'—':`${rate}%`}</strong><span>${rate===null?'No completed sessions':rate<75?'Needs attention':'On track'}</span></div>
     <p>${escapeHtml(guidance)}</p>
     ${rate!==null?`<div class="guidance-progress-track" role="img" aria-label="${rate}% attendance toward the 75% target"><span style="width:${Math.min(rate/75*100,100)}%"></span></div>`:''}
   </div>
   <div class="attendance-guidance-missed">
     <h3>Missed sessions <span>${missed.length}</span></h3>
     ${missed.length?`<ul>${missed.slice(0,4).map(session=>`<li><strong>${escapeHtml(session.title)}</strong><small>${dateText(session.event_date)}</small></li>`).join('')}</ul>${missed.length>4?`<small class="muted">And ${missed.length-4} more in your attendance history.</small>`:''}`:'<p class="muted">No missed sessions recorded.</p>'}
   </div>`;
 const next=$('next-session');
 if(!upcoming.length){
   next.innerHTML='<span class="eyebrow">UP NEXT</span><h3>You’re all caught up</h3><p class="muted">There are no upcoming active sessions right now. Check back here for your next NSTP activity.</p>';
   return;
 }
 const session=upcoming[0];
 const isToday=session.event_date===today;
 next.innerHTML=`<span class="eyebrow">UP NEXT</span><span class="next-session-date">${isToday?'Today':dateText(session.event_date)}${session.start_time?` · ${sessionTimeText(session.start_time,session.start_at)}`:''}</span><h3>${escapeHtml(session.title)}</h3><p class="muted">${escapeHtml(session.location||'Location not set')}</p><span class="next-session-hint">${isToday?'Happening today':'Add it to your calendar'}</span>`;
}
function renderStudentNotifications(sessions, tasks){
  const root = $('student-notifications');
  const today = todayText();
  const upcomingSessions = sessions
    .filter(session => session.active && session.event_date >= today)
    .sort((a, b) => a.event_date.localeCompare(b.event_date) || (a.start_time || '23:59').localeCompare(b.start_time || '23:59'))
    .slice(0, 3);

  const dueTasks = tasks
    .filter(task => !task.submission)
    .sort((a, b) => new Date(a.dueAt) - new Date(b.dueAt))
    .slice(0, 2);

  const alerts = [
    ...upcomingSessions.map(session => ({
      type: 'session',
      label: session.title,
      detail: `${dateText(session.event_date)} · ${sessionTimeText(session.start_time, session.start_at)}`,
      tone: 'session'
    })),
    ...dueTasks.map(task => ({
      type: 'task',
      label: task.title,
      detail: `Due ${timeText(task.dueAt)}`,
      tone: 'task'
    }))
  ];

  if (!alerts.length) {
    root.innerHTML = '<div class="notification-card empty"><span class="eyebrow">REMINDERS</span><p class="muted">No upcoming reminders. You’re all caught up.</p></div>';
    return;
  }

  root.innerHTML = `
    <div class="notification-card">
      <div class="section-title compact">
        <div><span class="eyebrow">REMINDERS</span><h2>Upcoming updates</h2></div>
      </div>
      <ul class="reminder-list">
        ${alerts.map(item => `
          <li class="reminder-item ${item.tone}">
            <span class="reminder-type">${item.type === 'session' ? 'Session' : 'Task'}</span>
            <div>
              <strong>${escapeHtml(item.label)}</strong>
              <small>${escapeHtml(item.detail)}</small>
            </div>
          </li>
        `).join('')}
      </ul>
    </div>
  `;
}
function calculateAttendanceStreak(sessions=[]){
 const attendedDates=[...new Set(sessions.filter(session => session.event_date && session.attendance_id).map(session => session.event_date))].sort((a,b)=>a.localeCompare(b));
 if(!attendedDates.length) return 0;
 let streak=0;
 let currentDate=new Date(`${attendedDates.at(-1)}T00:00:00`);
 while (true) {
   const key=`${currentDate.getFullYear()}-${String(currentDate.getMonth()+1).padStart(2,'0')}-${String(currentDate.getDate()).padStart(2,'0')}`;
   if (!attendedDates.includes(key)) break;
   streak += 1;
   currentDate.setDate(currentDate.getDate() - 1);
 }
 return streak;
}
function renderStudentSummary(sessions){
 const root=$('student-summary');
 const today=todayText();
 const past=sessions.filter(s=>s.event_date<=today);
 const attended=past.filter(s=>s.attendance_id).length;
 const rate=past.length?`${Math.round(attended/past.length*100)}%`:'—';
 const upcoming=sessions.filter(s=>s.active&&s.event_date>=today).length;
 const checkedOut=sessions.filter(s=>s.check_out).length;
 const streak=calculateAttendanceStreak(sessions);
 const items=[{label:'Attendance rate',value:rate},{label:'Sessions attended',value:sessions.filter(s=>s.attendance_id).length},{label:'Attendance streak',value:`${streak} day${streak===1?'':'s'}`},{label:'Upcoming sessions',value:upcoming},{label:'Checked out',value:checkedOut}];
 root.innerHTML=items.map(item=>`<div class="summary-card"><span class="summary-label">${item.label}</span><strong>${item.value}</strong></div>`).join('');
}
function escapeCalendarText(value){
 return String(value??'').replace(/\\/g,'\\\\').replace(/\r\n|\r|\n/g,'\\n').replace(/([,;])/g,'\\$1');
}
function foldCalendarLine(line){
 let output='';
 let current='';
 let byteCount=0;
 for(const character of line){
  const characterBytes=new TextEncoder().encode(character).length;
  if(byteCount+characterBytes>75){output+=`${current}\r\n `;current='';byteCount=1;}
  current+=character;
  byteCount+=characterBytes;
 }
 return output+current;
}
function downloadSessionCalendar(session){
 const start=session.start_at?new Date(session.start_at):new Date(`${session.event_date}T${(session.start_time||'09:00').slice(0,5)}:00`);
 if(!Number.isFinite(start.getTime())){showNotice('This session does not have a valid start time.');return;}
 const end=new Date(start.getTime()+60*60*1000);
 const toUtc=value=>value.toISOString().replace(/[-:]/g,'').replace(/\.\d{3}/,'');
 const lines=[
  'BEGIN:VCALENDAR','VERSION:2.0','PRODID:-//NSTP Attendance Monitoring System//EN','CALSCALE:GREGORIAN','BEGIN:VEVENT',
  `UID:nstp-session-${session.id}@attendance.local`,
  `DTSTAMP:${toUtc(new Date())}`,
  `DTSTART:${toUtc(start)}`,
  `DTEND:${toUtc(end)}`,
  `SUMMARY:${escapeCalendarText(session.title)}`,
  `LOCATION:${escapeCalendarText(session.location||'Location not set')}`,
  `DESCRIPTION:${escapeCalendarText('NSTP attendance session')}`,
  'END:VEVENT','END:VCALENDAR'
 ];
 const calendar=lines.map(foldCalendarLine).join('\r\n')+'\r\n';
 const file=new Blob([calendar],{type:'text/calendar;charset=utf-8'});
 const url=URL.createObjectURL(file);
 const link=document.createElement('a');
 const name=String(session.title||'nstp-session').toLowerCase().replace(/[^a-z0-9]+/g,'-').replace(/^-|-$/g,'')||'nstp-session';
 link.href=url;
 link.download=`${name}.ics`;
 document.body.append(link);
 link.click();
 link.remove();
 setTimeout(()=>URL.revokeObjectURL(url),1000);
}
function renderStudentSessions(sessions){
 const root=$('student-sessions');
 const filtered=filterSessions(sessions,studentQuery);
 if(!filtered.length){
   root.innerHTML=`<div class="empty-state">${sessions.length?'No sessions match your search.':'No NSTP sessions have been scheduled yet.'}</div>`;
   return;
 }
 const today=todayText();
 root.innerHTML=filtered.map(s=>{
   const status=s.event_date>=today&&s.active?'UPCOMING':s.active?'COMPLETED':'CLOSED';
   const startTimestamp=s.start_at?new Date(s.start_at).getTime():s.start_time?new Date(`${s.event_date}T${s.start_time.slice(0,5)}:00`).getTime():null;
   const canAddToCalendar=s.active&&(s.event_date>today||(s.event_date===today&&(startTimestamp===null||startTimestamp>Date.now())));
   return `<article class="session-card"><div class="card-top"><span class="pill ${status==='CLOSED'?'inactive':''}">${status}</span><span class="muted small">${s.attendance_id?'RECORDED':'NOT MARKED'}</span></div><h3>${escapeHtml(s.title)}</h3><div class="card-meta">${dateText(s.event_date)} · ${sessionTimeText(s.start_time,s.start_at)}<br>${escapeHtml(s.location||'Location not set')}</div><div class="card-meta attendance-times"><span>CHECK IN</span>${timeText(s.check_in)}<span>CHECK OUT</span>${timeText(s.check_out)}</div>${canAddToCalendar?`<div class="card-actions"><button class="button light" type="button" data-calendar-session="${Number(s.id)}">Add to calendar</button></div>`:''}</article>`;
 }).join('');
 root.querySelectorAll('[data-calendar-session]').forEach(button=>{
  const session=filtered.find(item=>String(item.id)===button.dataset.calendarSession);
  if(session)button.addEventListener('click',()=>downloadSessionCalendar(session));
 });
}

$('new-session').addEventListener('click',()=>openSessionDialog());
$('create-section').addEventListener('click',async()=>{
 const name=$('new-section-name').value.trim();
 if(!name){showNotice('Enter a section name.');return;}
 try{await api('/api/sections',{method:'POST',body:JSON.stringify({name})});$('new-section-name').value='';await renderDashboard();showNotice('Section added.',true);}catch(error){showNotice(error.message);}
});
$('new-section-name').addEventListener('keydown',event=>{if(event.key==='Enter'){event.preventDefault();$('create-section').click();}});
$('new-task').addEventListener('click',()=>{$('task-form').reset();$('task-due').value=localDateTimeValue(Date.now()+86400000);$('task-dialog').showModal();});
$('task-form').addEventListener('submit',async event=>{
 event.preventDefault();
 const body={title:$('task-title').value,description:$('task-description').value,dueAt:new Date($('task-due').value).toISOString(),sectionId:$('task-section').value};
 try{await api('/api/tasks',{method:'POST',body:JSON.stringify(body)});$('task-dialog').close();await renderDashboard();showNotice('Task created.',true);}catch(error){showNotice(error.message);}
});
$('close-task-submissions').addEventListener('click',()=>$('task-submissions-panel').classList.add('hidden'));
$('show-student-qr').addEventListener('click',showStudentQr);
$('copy-student-qr').addEventListener('click',async()=>{
 try{await navigator.clipboard.writeText(studentQrValue);showNotice('Student QR value copied. It is valid for 10 minutes.',true);}
 catch(error){showNotice('Could not copy the QR value. Ask the admin to scan the QR displayed here.');}
});
$('admin-submit-token').addEventListener('click',()=>submitStudentToken($('admin-manual-token').value));
$('admin-manual-token').addEventListener('keydown',event=>{if(event.key==='Enter'){event.preventDefault();submitStudentToken(event.currentTarget.value);}});
$('admin-scan-session').addEventListener('change',()=>stopAdminCamera());
document.querySelectorAll('.admin-scan-action').forEach(button=>button.addEventListener('click',()=>{
 adminScanAction=button.dataset.action;
 document.querySelectorAll('.admin-scan-action').forEach(item=>item.classList.toggle('active',item===button));
}));
$('admin-start-scan').addEventListener('click',startAdminCamera);
$('admin-stop-scan').addEventListener('click',stopAdminCamera);
$('search-input').addEventListener('input', event => { sessionQuery = event.target.value; if (currentUser && currentUser.role === 'admin') renderAdminSessions(dashboardSessions); });
$('student-search-input').addEventListener('input', event => { studentQuery = event.target.value; if (currentUser && currentUser.role !== 'admin') renderStudentSessions(dashboardSessions); });
$('download-student-attendance').addEventListener('click',()=>{
 const today=todayText();
 const reportSessions=[...dashboardSessions].sort((a,b)=>a.event_date.localeCompare(b.event_date));
 const statusFor=session=>session.attendance_id?'Attended':session.event_date>=today&&session.active?'Upcoming':session.event_date>today?'Closed':'Missed';
 const csvCell=value=>{
  let text=String(value??'');
  if(/^[\t\r ]*[=+\-@]/.test(text))text=`'${text}`;
  return `"${text.replace(/"/g,'""')}"`;
 };
 const rows=[
  ['Date','Session','Status','Check-in','Check-out'],
  ...reportSessions.map(session=>[session.event_date,session.title,statusFor(session),session.check_in||'',session.check_out||''])
 ];
 const file=new Blob([`\uFEFF${rows.map(row=>row.map(csvCell).join(',')).join('\r\n')}`],{type:'text/csv;charset=utf-8'});
 const url=URL.createObjectURL(file);
 const link=document.createElement('a');
 link.href=url;
 link.download='nstp-my-attendance.csv';
 document.body.append(link);
 link.click();
 link.remove();
 setTimeout(()=>URL.revokeObjectURL(url),1000);
});
$('print-student-attendance').addEventListener('click',()=>{
 const today=todayText();
 const reportSessions=[...dashboardSessions].sort((a,b)=>a.event_date.localeCompare(b.event_date));
 const statusFor=session=>session.attendance_id?'Attended':session.event_date>=today&&session.active?'Upcoming':session.event_date>today?'Closed':'Missed';
 const attended=reportSessions.filter(session=>statusFor(session)==='Attended').length;
 const missed=reportSessions.filter(session=>statusFor(session)==='Missed').length;
 const upcoming=reportSessions.filter(session=>statusFor(session)==='Upcoming').length;
 $('attendance-print-report').innerHTML=`
   <header class="print-report-heading">
     <span>NSTP ATTENDANCE MONITORING SYSTEM</span>
     <h1>My Attendance Report</h1>
     <p>${escapeHtml(currentUser.name)} · Generated ${escapeHtml(new Date().toLocaleString())}</p>
   </header>
   <div class="print-report-metrics">
     <div><span>Attended</span><strong>${attended}</strong></div>
     <div><span>Missed</span><strong>${missed}</strong></div>
     <div><span>Upcoming</span><strong>${upcoming}</strong></div>
   </div>
   <table class="print-report-table">
     <thead><tr><th>Date</th><th>Session</th><th>Status</th><th>Check-in</th><th>Check-out</th></tr></thead>
     <tbody>${reportSessions.map(session=>`<tr><td>${dateText(session.event_date)}</td><td>${escapeHtml(session.title)}</td><td>${statusFor(session)}</td><td>${timeText(session.check_in)}</td><td>${timeText(session.check_out)}</td></tr>`).join('')}</tbody>
   </table>`;
 window.print();
});
function openSessionDialog(session=null){$('session-form').reset();$('session-id').value=session?.id||'';$('dialog-title').textContent=session?'Edit session':'Create session';$('session-name').value=session?.title||'';$('event-date').value=session?.event_date||todayText();$('event-time').value=session?.start_time||'09:00';$('location').value=session?.location||'';$('session-section').value=session?.sectionId||'';$('active-wrap').classList.toggle('hidden',!session);$('session-active').checked=Boolean(session?.active);$('session-dialog').showModal();}
function editSession(id,sessions){const s=sessions.find(x=>x.id===id);if(s)openSessionDialog(s);}
$('session-form').addEventListener('submit',async event=>{event.preventDefault();const id=$('session-id').value;const eventDate=$('event-date').value;const startTime=$('event-time').value;const body={title:$('session-name').value,eventDate,startTime,startAt:new Date(`${eventDate}T${startTime}:00`).toISOString(),location:$('location').value,sectionId:$('session-section').value};if(id)body.active=$('session-active').checked;try{await api(id?`/api/sessions/${id}`:'/api/sessions',{method:id?'PUT':'POST',body:JSON.stringify(body)});$('session-dialog').close();await renderDashboard();showNotice(id?'Session updated.':'Session created.',true);}catch(e){showNotice(e.message);}});
async function deleteSession(id){if(!confirm('Delete this session and every attached attendance record?'))return;try{await api(`/api/sessions/${id}`,{method:'DELETE'});await renderDashboard();showNotice('Session deleted.',true);}catch(e){showNotice(e.message);}}
async function showRecords(id,title){
 activeSessionId=id;
 activeSessionTitle=title;
 $('records-title').textContent=title+' · roster & absences';
 $('records-panel').classList.remove('hidden');
 $('records-table').innerHTML='Loading…';
 try{
  const {attendance}=await api(`/api/sessions/${id}/attendance`);
  $('records-table').innerHTML=attendance.length?`<div class="table-wrap"><table><thead><tr><th>Student</th><th>Email</th><th>Status</th><th>Check in</th><th>Check out</th><th>Manage</th></tr></thead><tbody>${attendance.map(a=>`<tr><td>${escapeHtml(a.name)}</td><td>${escapeHtml(a.email)}</td><td><span class="pill ${a.status==='Absent'?'inactive':a.status==='Late'?'late':''}">${a.status}</span></td><td>${timeText(a.check_in)}</td><td>${timeText(a.check_out)}</td><td>${a.id?`<button class="table-action" data-edit-record="${a.id}" data-check-in="${escapeHtml(a.check_in)}" data-check-out="${escapeHtml(a.check_out||'')}">Edit</button><button class="table-action" data-delete-record="${a.id}">Delete</button>`:'—'}</td></tr>`).join('')}</tbody></table></div>`:'<div class="empty-state">No students are assigned to this session’s section yet.</div>';
  $('records-table').querySelectorAll('[data-edit-record]').forEach(button=>button.addEventListener('click',()=>{
   $('attendance-correction-id').value=button.dataset.editRecord;
   $('attendance-correction-check-in').value=localDateTimeValue(button.dataset.checkIn);
   $('attendance-correction-check-out').value=button.dataset.checkOut?localDateTimeValue(button.dataset.checkOut):'';
   $('attendance-correction-reason').value='';
   $('attendance-correction-dialog').showModal();
  }));
  $('records-table').querySelectorAll('[data-delete-record]').forEach(button=>button.addEventListener('click',async()=>{
   const reason=prompt('Why are you removing this attendance record? This reason will be recorded in the activity log.');
   if(reason===null)return;
   try{
    await api(`/api/attendance/${button.dataset.deleteRecord}`,{method:'DELETE',body:JSON.stringify({reason})});
    await showRecords(id,title);
    await renderDashboard();
   }catch(error){showNotice(error.message);}
  }));
 }catch(error){showNotice(error.message);}
}
$('attendance-correction-form').addEventListener('submit',async event=>{
 event.preventDefault();
 try{
  await api(`/api/attendance/${$('attendance-correction-id').value}`,{method:'PUT',body:JSON.stringify({
   checkIn:$('attendance-correction-check-in').value,
   checkOut:$('attendance-correction-check-out').value||null,
   reason:$('attendance-correction-reason').value
  })});
  $('attendance-correction-dialog').close();
  await showRecords(activeSessionId,activeSessionTitle);
  await renderDashboard();
  showNotice('Attendance record corrected and logged.',true);
 }catch(error){showNotice(error.message);}
});
$('close-records').addEventListener('click',()=>$('records-panel').classList.add('hidden'));
async function generateQr(id){try{const {image,expiresAt}=await api(`/api/sessions/${id}/qr`,{method:'POST',body:'{}'});activeSessionId=id;$('qr-image').src=image;$('qr-title').textContent='Scan to attend';$('qr-dialog').showModal();startCountdown(expiresAt);}catch(e){showNotice(e.message);}}
function startCountdown(expiresAt){clearInterval(qrInterval);const tick=()=>{const left=Math.max(0,expiresAt-Date.now());$('qr-timer').textContent=left?`Expires in ${Math.floor(left/60000)}:${String(Math.floor(left%60000/1000)).padStart(2,'0')}`:'QR expired — generate a new code';$('refresh-qr').textContent=left?'Generate new QR':'Refresh QR';};tick();qrInterval=setInterval(tick,1000);}
$('refresh-qr').addEventListener('click',()=>generateQr(activeSessionId));$('close-qr').addEventListener('click',()=>$('qr-dialog').close());$('close-records').addEventListener('click',()=>$('records-panel').classList.add('hidden'));
document.querySelectorAll('.scan-action').forEach(b=>b.addEventListener('click',()=>{scanAction=b.dataset.action;document.querySelectorAll('.scan-action').forEach(x=>x.classList.toggle('active',x===b));}));
function tokenFrom(value){const raw=String(value||'').trim();try{const url=new URL(raw,location.origin);return url.searchParams.get('scan')||raw;}catch{return raw;}}
async function submitToken(value){const token=tokenFrom(value);try{const data=await api('/api/attendance/scan',{method:'POST',body:JSON.stringify({token,action:scanAction})});$('manual-token').value='';showNotice(`Checked ${data.action.toUpperCase()} for ${data.session}.`,true);await stopCamera();await renderDashboard();}catch(e){showNotice(e.message);}}
$('submit-token').addEventListener('click',()=>submitToken($('manual-token').value));$('manual-token').addEventListener('keydown',e=>{if(e.key==='Enter'){e.preventDefault();submitToken(e.currentTarget.value);}});
let cameraStream=null, cameraTimer=null;
$('start-scan').addEventListener('click',startCamera);$('stop-scan').addEventListener('click',stopCamera);
async function startCamera(){if(!('BarcodeDetector'in window)){showNotice('QR camera scanning is not supported by this browser. Paste the QR link below instead.');return;}try{const detector=new BarcodeDetector({formats:['qr_code']});cameraStream=await navigator.mediaDevices.getUserMedia({video:{facingMode:'environment'},audio:false});const video=document.createElement('video');video.setAttribute('playsinline','');video.srcObject=cameraStream;$('camera').replaceChildren(video);await video.play();$('start-scan').classList.add('hidden');$('stop-scan').classList.remove('hidden');cameraTimer=setInterval(async()=>{if(video.readyState<2)return;try{const codes=await detector.detect(video);if(codes.length)await submitToken(codes[0].rawValue);}catch{}},500);}catch(e){showNotice(e.name==='NotAllowedError'?'Allow camera access to scan the QR code.':'Could not open the camera. You can paste the QR link instead.');}}
async function stopCamera(){clearInterval(cameraTimer);cameraTimer=null;if(cameraStream)cameraStream.getTracks().forEach(t=>t.stop());cameraStream=null;$('camera').replaceChildren();$('start-scan').classList.remove('hidden');$('stop-scan').classList.add('hidden');}
async function submitStudentToken(value){
 const token=String(value||'').trim();
 try{
  const result=await api('/api/admin/attendance/scan',{method:'POST',body:JSON.stringify({token,sessionId:$('admin-scan-session').value,action:adminScanAction})});
  $('admin-manual-token').value='';
  showNotice(`Checked ${result.action.toUpperCase()} for ${result.student}${result.section?` · ${result.section}`:''}.`,true);
  await stopAdminCamera();await renderDashboard();
 }catch(error){showNotice(error.message);}
}
let adminCameraStream=null,adminCameraTimer=null,adminScanBusy=false;
async function startAdminCamera(){
 if(!('BarcodeDetector'in window)){showNotice('QR camera scanning is not supported by this browser. Paste the student QR value instead.');return;}
 try{
  const detector=new BarcodeDetector({formats:['qr_code']});
  adminCameraStream=await navigator.mediaDevices.getUserMedia({video:{facingMode:'environment'},audio:false});
  const video=document.createElement('video');video.setAttribute('playsinline','');video.srcObject=adminCameraStream;
  $('admin-camera').replaceChildren(video);await video.play();
  $('admin-start-scan').classList.add('hidden');$('admin-stop-scan').classList.remove('hidden');
  adminCameraTimer=setInterval(async()=>{
   if(video.readyState<2||adminScanBusy)return;
   try{
    const codes=await detector.detect(video);
    if(codes.length){adminScanBusy=true;await submitStudentToken(codes[0].rawValue);adminScanBusy=false;}
   }catch{adminScanBusy=false;}
  },500);
 }catch(error){
  await stopAdminCamera();
  showNotice(error.name==='NotAllowedError'?'Allow camera access to scan student QR codes.':'Could not open the camera. Paste the student QR value instead.');
 }
}
async function stopAdminCamera(){
 clearInterval(adminCameraTimer);adminCameraTimer=null;adminScanBusy=false;
 if(adminCameraStream)adminCameraStream.getTracks().forEach(track=>track.stop());
 adminCameraStream=null;$('admin-camera').replaceChildren();
 $('admin-start-scan').classList.remove('hidden');$('admin-stop-scan').classList.add('hidden');
}
bootstrap();
